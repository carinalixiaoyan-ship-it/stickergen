import { GoogleGenAI } from "@google/genai";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates an edited image or sticker pack based on an input image and a text prompt.
 * Uses the 'gemini-2.5-flash-image' model (Nano Banana).
 */
export const generateImageEdit = async (
  imageBase64: string,
  prompt: string,
  mimeType: string = "image/jpeg"
): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: imageBase64,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    // Iterate through parts to find the image part
    if (response.candidates && response.candidates[0].content && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.data) {
          const base64Data = part.inlineData.data;
          // Determine mime type if possible, default to png as that's common for generation output
          const outputMimeType = part.inlineData.mimeType || "image/png";
          return `data:${outputMimeType};base64,${base64Data}`;
        }
      }
    }

    throw new Error("No image data found in the response.");
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
