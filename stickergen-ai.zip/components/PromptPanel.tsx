import React, { useState } from 'react';
import { Sparkles, Send, Sticker } from 'lucide-react';
import { STICKER_PRESET_PROMPT } from '../types';

interface PromptPanelProps {
  onGenerate: (prompt: string) => void;
  isProcessing: boolean;
  disabled: boolean;
}

const PromptPanel: React.FC<PromptPanelProps> = ({ onGenerate, isProcessing, disabled }) => {
  const [prompt, setPrompt] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim() && !disabled) {
      onGenerate(prompt);
    }
  };

  const handlePreset = () => {
    setPrompt(STICKER_PRESET_PROMPT);
    if (!disabled) {
      // Optional: Auto-submit on preset click? 
      // Let's just set it so user can review.
      // Or maybe auto-submit for better UX. Let's auto-submit after a tiny delay or just set it.
      // Let's just set it.
    }
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-xl">
      <div className="flex items-center space-x-2 mb-4">
        <Sparkles className="text-rose-400" size={20} />
        <h2 className="text-lg font-semibold text-white">Magic Editor</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="prompt" className="text-sm text-slate-400 font-medium">
            Describe how you want to transform the image
          </label>
          <textarea
            id="prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={isProcessing || disabled}
            placeholder="E.g., Make it cyberpunk style, remove background, turn into a cartoon..."
            className="w-full h-32 bg-slate-900 border border-slate-700 rounded-lg p-3 text-slate-100 placeholder-slate-500 focus:ring-2 focus:ring-rose-500 focus:border-transparent outline-none resize-none transition-all"
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={handlePreset}
            disabled={isProcessing || disabled}
            className="flex-1 flex items-center justify-center space-x-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed text-white py-3 px-4 rounded-lg transition-all font-medium border border-slate-600 group"
          >
            <Sticker size={18} className="text-rose-300 group-hover:scale-110 transition-transform" />
            <span>Sticker Pack Preset</span>
          </button>
          
          <button
            type="submit"
            disabled={isProcessing || disabled || !prompt.trim()}
            className="flex-[2] flex items-center justify-center space-x-2 bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed text-white py-3 px-4 rounded-lg transition-all font-bold shadow-lg shadow-rose-500/20"
          >
            {isProcessing ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Creating Magic...</span>
              </>
            ) : (
              <>
                <Sparkles size={18} />
                <span>Generate</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PromptPanel;
