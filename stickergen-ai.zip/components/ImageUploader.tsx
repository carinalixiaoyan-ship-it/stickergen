import React, { useCallback, useState } from 'react';
import { Upload, X, Image as ImageIcon } from 'lucide-react';

interface ImageUploaderProps {
  onImageSelect: (base64: string, mimeType: string) => void;
  selectedImage: string | null;
  onClear: () => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageSelect, selectedImage, onClear }) => {
  const [isDragging, setIsDragging] = useState(false);

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      // Extract base64 data and mime type
      // result looks like "data:image/jpeg;base64,....."
      const [header, base64Data] = result.split(',');
      const mimeType = header.match(/:(.*?);/)![1];
      
      onImageSelect(base64Data, mimeType);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  }, [onImageSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  if (selectedImage) {
    return (
      <div className="relative w-full h-64 md:h-96 bg-slate-800 rounded-xl overflow-hidden border border-slate-700 group">
        <img 
          src={`data:image/jpeg;base64,${selectedImage}`} 
          // Note: we're reconstructing the data URI here assuming jpeg for preview if raw base64 passed, 
          // but usually onImageSelect logic keeps it separated. 
          // Let's adjust: The parent passes the full data URI or we handle it.
          // For simplicity, let's assume selectedImage passed in is the BASE64 string only. 
          // Actually, for display, it's safer if parent passes full data URI or we guess.
          // Let's rely on the parent sending a full Data URI or we prepend a generic header for preview if needed.
          // Update: Let's assume the parent handles the prefix or we just try generic.
           alt="Selected" 
           className="w-full h-full object-contain"
        />
        <button 
          onClick={onClear}
          className="absolute top-2 right-2 p-2 bg-black/50 hover:bg-red-500/80 text-white rounded-full transition-colors backdrop-blur-sm"
        >
          <X size={20} />
        </button>
      </div>
    );
  }

  return (
    <div
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      className={`
        relative w-full h-64 md:h-96 border-2 border-dashed rounded-xl flex flex-col items-center justify-center transition-all cursor-pointer
        ${isDragging 
          ? 'border-rose-500 bg-rose-500/10' 
          : 'border-slate-600 hover:border-slate-500 hover:bg-slate-800/50 bg-slate-800/20'}
      `}
    >
      <input
        type="file"
        accept="image/*"
        onChange={handleFileInput}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
      />
      <div className="flex flex-col items-center space-y-4 text-slate-400">
        <div className={`p-4 rounded-full ${isDragging ? 'bg-rose-500/20 text-rose-400' : 'bg-slate-700 text-slate-300'}`}>
          {isDragging ? <Upload size={32} /> : <ImageIcon size={32} />}
        </div>
        <div className="text-center">
          <p className="font-medium text-lg text-slate-200">
            {isDragging ? 'Drop image here' : 'Click or drop image'}
          </p>
          <p className="text-sm mt-1">Supports JPG, PNG, WEBP</p>
        </div>
      </div>
    </div>
  );
};

export default ImageUploader;
