import React from 'react';
import { Download, RefreshCcw, ExternalLink } from 'lucide-react';

interface ResultDisplayProps {
  resultImage: string | null;
  onReset: () => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ resultImage, onReset }) => {
  if (!resultImage) return null;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = resultImage;
    link.download = `sticker-gen-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-xl animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-white">Result</h2>
        <div className="flex space-x-2">
          <button
            onClick={onReset}
            className="p-2 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition-colors"
            title="Clear Result"
          >
            <RefreshCcw size={20} />
          </button>
        </div>
      </div>

      <div className="relative rounded-lg overflow-hidden bg-slate-900 border border-slate-800 group">
        <img 
          src={resultImage} 
          alt="Generated Result" 
          className="w-full h-auto max-h-[600px] object-contain mx-auto"
        />
        
        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
          <button
            onClick={handleDownload}
            className="bg-white text-slate-900 px-6 py-3 rounded-full font-bold flex items-center space-x-2 hover:scale-105 transition-transform shadow-xl"
          >
            <Download size={20} />
            <span>Download Image</span>
          </button>
        </div>
      </div>
      
      <p className="text-slate-500 text-sm mt-4 text-center">
        Generated with Gemini 2.5 Flash Image
      </p>
    </div>
  );
};

export default ResultDisplay;
